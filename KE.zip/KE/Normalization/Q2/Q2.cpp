#include<bits/stdc++.h>
using namespace std;

int mean(vector<int> &data){
    double x = 0.0;
    int count = 0;
    for(auto i : data){
        x += i;
        count++;
    }
    return floor(x/count);
}

vector<int> bound(vector<int> &data){
    int mx = *max_element(data.begin(),data.end());
    int mn = *min_element(data.begin(),data.end());
    int N = data.size();
    vector<int> result(N);
    for(int i = 0;i < N;i++){
        if(abs(data[i] - mx) > abs(data[i] - mn)) result[i] = mn;
        else result[i] = mx; 
    }
    return result;
}

void print(vector<vector<int>> &bins){
    cout<<"\n---------------------------\n";
    int k = 1;
    for(auto i : bins){
        cout<<"Bin "<<k<<" : ";
        for(auto j : i) cout<<j<<' ';
        cout<<'\n';
        k++;
    }
    cout<<"---------------------------\n";
} 

void write_on_file(vector<vector<int>> &bins,fstream &wrt){
    for(auto i : bins){
        for(auto j : i){
            wrt<<j<<'\n';
        }
    }
}

vector<vector<int>> partition(vector<int> &data,int num_bin){
    vector<vector<int>> result(num_bin);
    int N = data.size(),k = 0,bin_size = N / num_bin;
    for(int i = 0;i < num_bin;i++){
        int x = bin_size;
        while(k < N && x > 0){
            result[i].push_back(data[k]);
            k++;
            x--;
        }
    }
    while(k < N){
        result.back().push_back(data[k]);
        k++;
    }
    return result;
}

vector<vector<int>> bining_by_means(vector<vector<int>> &bins){
    int N = bins.size();
    vector<vector<int>> result;
    for(int i = 0;i < N;i++){
        int x = mean(bins[i]);
        vector<int> nw(bins[i].size(),x);
        result.push_back(nw);
    }
    return result;
}

vector<vector<int>> bining_by_boundaries(vector<vector<int>> &bins){
    int N = bins.size();
    vector<vector<int>> result;
    for(int i = 0;i < N;i++){
        vector<int> nw = bound(bins[i]);
        result.push_back(nw);
    }
    return result;
}

void perform_bining(fstream &rd,int no_bins,string database){
    string x;
    vector<int> data;
    fstream wrt;
    while(rd>>x){
        data.push_back(stoi(x));
    }
    
    sort(data.begin(),data.end());

    cout<<"\nDatabase : "<<database<<'\n'; 
    vector<vector<int>> bins = partition(data,no_bins),result;
    cout<<"\nPartition into (equal-frequency) bins : \n";
    print(bins);

    cout<<"\n1.Smoothing by bin means : \n";
    result = bining_by_means(bins);
    wrt.open(database + "_bining_means.txt",ios::out);
    print(result); 
    write_on_file(result,wrt);
    wrt.close();

    cout<<"\n2.Smoothing by bin boundaries : \n";
    result = bining_by_boundaries(bins);
    wrt.open(database + "_bining_boundaries.txt",ios::out);
    print(result); 
    write_on_file(result,wrt);
    wrt.close();
}

int main(){
    fstream rd;
    /*
    rd.open("book_data.txt",ios::in);
    perform_bining(rd,3,"book_data");
    rd.close();
    */
    rd.open("data.txt",ios::in);
    perform_bining(rd,5,"random_data");
    rd.close();   
}