#include<bits/stdc++.h>
using namespace std;
#define NA INT_MAX

int mean(vector<int> &data){
    double x = 0.0;
    int count = 0;
    for(auto i : data){
        if(i != NA){
            x += i;
            count++;
        }
    }
    return floor(x/count);
}

pair<string,int> Tuple(string &S){
    string label,data;
    int i = 0;
    while(S[i] != ' '){
        label.push_back(S[i]);
        i++;
    }
    i++;
    while(i < S.length()){
        data.push_back(S[i]);
        i++;
    }
    if(data == "NA") return {label,NA};
    return {label,stoi(data)};
}

vector<int> fill_mean(vector<int> &data){
    int x = mean(data);
    vector<int> result(data.size());
    for(int i = 0;i < data.size();i++){
        if(data[i] == NA) result[i] = x;
        else result[i] = data[i];
    }
    return result;
}

int main(){
    fstream rd,wrt;
    string x;
    rd.open("data.txt",ios::in);
    wrt.open("data_filled.txt",ios::out);
    unordered_map<string,vector<int>> data;
    while(getline(rd,x)){
        auto pr = Tuple(x);
        data[pr.first].push_back(pr.second);
    }
    cout<<"\nData before filling missing values : \n";
    for(auto i : data){
        for(auto k : i.second){
            if(k != NA) cout<<i.first<<' '<<k<<'\n';
            else cout<<i.first<<" NA\n";
        }
        data[i.first] = fill_mean(i.second);
    }
    cout<<"\nData after filling missing values : \n";
    for(auto i : data){
        for(auto k : i.second){
            cout<<i.first<<' '<<k<<'\n';
            wrt<<i.first<<' '<<k<<'\n';
        }
    }
}