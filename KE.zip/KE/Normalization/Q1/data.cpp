#include<bits/stdc++.h>
using namespace std;
int random_int(int l,int h){
    return rand()%(h - l + 1) + l;
}
int main(){
    fstream wrt;
    wrt.open("data.txt",ios::out);
    cout<<"databse created : data.txt"<<'\n';
    wrt<<"NAN"<<'\n'<<"NAN"<<'\n'; 
    cout<<"NAN"<<'\n'<<"NAN"<<'\n';
    for(int i = 0;i < 18;i++){
        int x = random_int(1,1000);
        cout<<x<<'\n';
        wrt<<x<<'\n';
    }
}