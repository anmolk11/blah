#include<bits/stdc++.h>
using namespace std;
#define NA INT_MIN

void print(vector<int> &data){
    cout<<"\n--------------\n";
    for(auto i : data){
        if(i == NA) cout<<"NA"<<'\n';
        else cout<<i<<'\n';
    }
    cout<<"\n--------------\n";
}

void write_on_file(vector<int> &data,fstream &obj){
    for(auto i : data){
        obj<<i<<'\n';
    }
}

int mean(vector<int> &data){
    double x = 0.0;
    int count = 0;
    for(auto i : data){
        if(i != NA) x += i,count++;
    }
    return floor(x/count);
}

vector<int> ingnore_na(vector<int> &data){
    vector<int> result;
    for(auto i : data){
        if(i != NA) result.push_back(i);
    }
    return result;
}

vector<int> fill_constant(int C,vector<int> &data){
    vector<int> result;
    for(auto i : data){
        if(i == NA) result.push_back(C);
        else result.push_back(i);
    }
    return result;
}

vector<int> fill_mean(vector<int> &data){
    vector<int> result;
    int x = mean(data);
    for(auto i : data){
        if(i == NA) result.push_back(x);
        else result.push_back(i);
    }
    return result;
}


int main(){
    fstream wrt,rd;
    vector<int> data,result;
    string x;
    rd.open("data.txt",ios::in);
    while(rd>>x){
        if(x == "NAN") data.push_back(NA);
        else data.push_back(stoi(x));
    }
    cout<<"Data before filling missing values : \n";
    print(data);
    
    cout<<"\n1.Ignore the tuple\n";
    result = ingnore_na(data);
    wrt.open("ignore_na.txt",ios::out);
    print(result);
    write_on_file(result,wrt);
    wrt.close();
    
    cout<<"\n2.Use constant to fill in the missing values\n";
    result = fill_constant(INT_MAX,data);
    wrt.open("fill_const.txt",ios::out);
    print(result);
    write_on_file(result,wrt);
    wrt.close();

    cout<<"3.Use mean to fill in the missing values\n";
    result = fill_mean(data);
    wrt.open("fill_mean.txt",ios::out);
    print(result);
    write_on_file(result,wrt);
    wrt.close();
}