#include<bits/stdc++.h>
using namespace std;

template<class T>
void print(vector<vector<T>> &data){
    int N = data[0].size();
    cout<<"\n------------------------\n";
    for(int i = 0;i < N;i++){
        cout<<data[0][i]<<setw(15)<<data[1][i]<<'\n';
    }
    cout<<"------------------------\n";
}

pair<float,float> calculateSD(vector<int> &data) {
  float sum = 0.0, mean, standardDeviation = 0.0;
  int i,N = data.size();
  for(i = 0; i < N; ++i) {
    sum += data[i];
  }

  mean = sum / N;
  for(i = 0; i < N; ++i) {
    standardDeviation += pow(data[i] - mean, 2);
  }

  standardDeviation = sqrt(standardDeviation / N);
  return {mean,standardDeviation};
}

pair<int,int> Tuple(string &S){
    string d1,d2;
    int i = 0;
    while(S[i] != ' '){
        d1.push_back(S[i]);
        i++;
    }
    i++;
    while(i < S.length()){
        d2.push_back(S[i]);
        i++;
    }
    return {stoi(d1),stoi(d2)};
}

vector<float> min_max(vector<int> &data){
    int N = data.size();
    int mn = *min_element(data.begin(),data.end());
    int mx = *max_element(data.begin(),data.end());
    vector<float> res(N);
    for(int i = 0;i < N;i++){
        res[i] = (data[i] - mn + 0.0) / (mx - mn + 0.0); 
    }
    return res;
} 

vector<float> z_score(vector<int> &data){
    int N = data.size();
    auto pr = calculateSD(data);
    vector<float> result(N);
    for(int i = 0;i < N;i++){
        result[i] = (data[i] - pr.first) / pr.second;
    }
    return result;
}

vector<float> decimal_scaling(vector<int> &data){
    int N = data.size(),mx_abs = 0;
    vector<float> result(N);
    for(auto i : data) mx_abs = max(mx_abs,abs(i));
    int dig_count = log10(mx_abs) + 1;
    int pw = pow(10,dig_count);
    for(int i = 0;i < N;i++){
        result[i] = (data[i] + 0.0) / pw;  
    }
    return result;
}

int main(){
    fstream rd;
    string x;
    vector<vector<int>> data(2);
    vector<vector<float>> result(2);

    rd.open("data.txt",ios::in);

    while(getline(rd,x)){
        auto pr = Tuple(x);
        data[0].push_back(pr.first);
        data[1].push_back(pr.second);
    }

    cout<<"\nData before normalization : \n";
    print(data);

    cout<<"\nMin - Max Normalization : \n";
    result[0] = min_max(data[0]);
    result[1] = min_max(data[1]);
    print(result);

    cout<<"\nZ score Normalization : \n";
    result[0] = z_score(data[0]);
    result[1] = z_score(data[1]);
    print(result);

    cout<<"\nDecimal scalling Normalization : \n";
    result[0] = decimal_scaling(data[0]);
    result[1] = decimal_scaling(data[1]);
    print(result);
}