#include <bits/stdc++.h>

using namespace std;

struct DTreeNode {
    string attr;
    bool isLeaf;
    map<string, DTreeNode*> child;
};

vector<string> attrs;
map<string, int> attrLocMap;
vector<vector<string> > tuples;
map<string, set<string> > attrValues;

void readDB() {
    int numAttrs, numTuples;
    ifstream fin("database.txt", ios::in);
    fin >> numAttrs;
    fin >> numTuples;
    for (int i = 0; i < numAttrs; i++) {
        string attr; 
        fin >> attr; 
        attrs.push_back(attr);
        attrLocMap[attr] = i;
    }

    for (int i = 0; i < numTuples; i++) {
        vector<string> tuple;
        for (int j = 0; j < numAttrs; j++) {
            string val; 
            fin >> val; 
            tuple.push_back(val);
            attrValues[attrs[j]].insert(val);
        }
        tuples.push_back(tuple);
    }
}

string selectBestAttr(vector<string> remAttrs, vector<vector<string> > remTups) {
    // Calculating the expected information needed to classify the remaining dataset D
    map<string, int> classLabels;
    for (int i = 0; i < remTups.size(); i++)
        classLabels[remTups[i][remTups[i].size() - 1]]++;

    double infoD = 0.0;
    for (auto it: classLabels) {
        double p = (double)it.second / (double)remTups.size();
        infoD -= (p * log2(p));
    }

    string bestAttr;
    double maxInfoGain = DBL_MIN;

    // Calculating the entropy of each remaining attribute, and thus calculating
    // the information gain for each attribute
    for (int i = 0; i < remAttrs.size() - 1; i++) {
        double infoD_i = 0.0;
        for (auto val: attrValues[remAttrs[i]]) {
            double infoD_j = 0.0;

            vector<vector<string> > tuples;
            for (int j = 0; j < remTups.size(); j++)
                if (remTups[j][attrLocMap[remAttrs[i]]] == val)
                    tuples.push_back(remTups[j]);

            if (tuples.size() == 0) continue;

            map<string, int> attrClassLabels;
            for (int k = 0; k < tuples.size(); k++)
                attrClassLabels[tuples[k][tuples[k].size() - 1]]++;

            for (auto it: attrClassLabels) {
                double p = (double)it.second / (double)tuples.size();
                infoD_j -= (p * log2(p));
            }

            infoD_i += ((double)tuples.size() / (double)remTups.size()) * infoD_j ;
        }

        // Selecting the attribute with maximum information gain
        double infoGain = infoD - infoD_i;
        if (infoGain > maxInfoGain) {
            maxInfoGain = infoGain;
            bestAttr = remAttrs[i];
        }
    }
    
    return bestAttr;
}

DTreeNode* createTree(vector<string> remAttrs, vector<vector<string> > remTups) {
    //if (remTups.size() == 1) return NULL;

    DTreeNode* newNode = new DTreeNode;

    // Checking if the dataset contains only a single class
    bool containsSingleClass = true;
    string cls = remTups[0][remTups[0].size() - 1];
    for (int i = 1; i < remTups.size(); i++) {
        if (remTups[i][remTups[i].size() - 1] != cls) {
            containsSingleClass = false;
            break;
        }
    }

    // Marking the node as leaf node if it contains a single class
    if (containsSingleClass) {
        newNode->isLeaf = true;
        newNode->attr = cls;
        return newNode;
    }

    // If there are no more attributes to select from, the node should be made
    // a leaf node with the majority class as the class label
    if (remAttrs.size() == 0) {
        map<string, int> classLabels;
        for (int i = 0; i < remTups.size(); i++)
            classLabels[cls]++;

        int maxFreq = 0;
        string majorityClass;
        for (auto it: classLabels) {
            if (it.second > maxFreq) {
                maxFreq = it.second;
                majorityClass = it.first;
            }
        }

        newNode->isLeaf = true;
        newNode->attr = majorityClass;
        return newNode;
    }

    string bestSplitAttr = selectBestAttr(remAttrs, remTups);
    newNode->attr = bestSplitAttr;
    newNode->isLeaf = false;
  
    vector<string> newRemAttrs;
    for (int i = 0; i < remAttrs.size(); i++)
        if (remAttrs[i] != bestSplitAttr) 
            newRemAttrs.push_back(remAttrs[i]);

    set<string> distinctAttrVals = attrValues[bestSplitAttr];
    // For each outcome j of the best splitting criteria
    for (auto val: distinctAttrVals) {
        vector<vector<string> > newRemTuples;
        for (int i = 0; i < remTups.size(); i++)
            if (remTups[i][attrLocMap[bestSplitAttr]] == val)
                newRemTuples.push_back(remTups[i]);
    
        // If the partition is empty with respect to the jth attribute, then a leaf
        // node needs to be attached to the current node with majority class in D
        if (newRemTuples.size() == 0) {
            map<string, int> classLabels;

            for (int i = 0; i < remTups.size(); i++)
                classLabels[remTups[i][remTups[i].size() - 1]]++;

            int maxFreq = 0;
            string majorityClass;
            for (auto it2: classLabels) {
                if (it2.second > maxFreq) {
                    maxFreq = it2.second;
                    majorityClass = it2.first;
                }
            }

            DTreeNode* tempNode = new DTreeNode;
            tempNode->isLeaf = true;
            tempNode->attr = majorityClass;
            newNode->child[val] = tempNode;
        } else {
            newNode->child[val] = createTree(newRemAttrs, newRemTuples);
        }
    }

    return newNode;
}

void inorder(DTreeNode* root) {
    if (!root) return;
    if (!root->isLeaf) cout << root->attr << "(" << (root->child).size() << ") ->" << endl;
    if (root->isLeaf) cout << root->attr;
    for (auto it: root->child) {
        cout << it.first << ": ";
        inorder(it.second);
        cout << endl;
    }
}

int main() {
    readDB();

    DTreeNode* root = createTree(attrs, tuples);
  
    inorder(root);
  
    return 0;
}