#include<bits/stdc++.h>
using namespace std;

unordered_map<string,unordered_set<string>> unqAttrbClass;

vector<string> Attrb;

vector<vector<string>> database;

unordered_map<string,int> inverseMapper;


struct Node{
    string attrb;
    bool isLeaf;
    unordered_map<string,Node*> branch;
};

vector<string> split(string &A){
    vector<string> res;
    stringstream obj(A);
    string x;
    while(obj>>x) res.push_back(x);  
    return res;
}

void database_reader(string filename){
    fstream rd;
    rd.open(filename,ios::in);
    int k = 0;
    string x;
    
    while(getline(rd,x)){
        vector<string> A = split(x);
        if(k == 0){
            Attrb = A;
            Attrb.pop_back();
            for(int i = 0;i < A.size();i++) inverseMapper[A[i]] = i;
        }
        else{
            database.push_back(A);
            for(int i = 0;i < A.size();i++){
                unqAttrbClass[Attrb[i]].insert(A[i]);
            }
        }
        k++;
    } 
}

string bestSlittingMeasure(vector<vector<string>> &database,vector<string> &remAttrb){
    double mxInfoGain = 0.0,infoD = 0.0;
    string bestAttrb;
    int total;
    int yes = 0,no = 0;

    for(auto i : database) i.back() == "yes" ? yes++ : no++;

    total = yes + no;

    double pYes = (yes + 0.0)/total,pNo = (no + 0.0)/total;
    infoD = -(pYes * log2(pYes) + pNo * log2(pNo));

    for(auto i : remAttrb){
        double curr_info = 0.0;
        unordered_map<string,pair<int,int>> freq_count;
        int ind = inverseMapper[i];
        for(auto j : database){
            string cls = j.back(),attrbCls = j[ind];
            if(cls == "yes") freq_count[attrbCls].first += 1;
            else freq_count[attrbCls].second += 1;
        }        
        for(auto j : freq_count){
            int ttl = j.second.first + j.second.second;
            double prob = ((ttl + 0.0)/total);
            pYes = (0.0 + j.second.first)/ttl,pNo = (0.0 + j.second.second)/ttl;
    
            if(pYes != 0.0){
                double entrpy = -pYes*log2(pYes);
                curr_info += entrpy * prob;
            }
            if(pNo != 0.0){
                double entrpy = -pNo*log2(pNo);
                curr_info += entrpy * prob;
            }         
        }
        double currInfoGain =  infoD - curr_info;
        if(currInfoGain > mxInfoGain){
            mxInfoGain = currInfoGain;
            bestAttrb = i;
        }
    }
    return bestAttrb;
}

Node* bulidTree(vector<vector<string>> &database,vector<string> &remAttrb){
    Node *root = new Node;
    bool sameClass = 1;
    string cls = database[0].back();
    
    for(auto i : database){
        if(i.back() != cls){
            sameClass = 0;
            break;
        }
    }
    // all in same class;
    if(sameClass){
        root->isLeaf = 1;
        root->attrb = cls;
        return root;
    }


    // attribute list empty
    if((remAttrb.empty())){
        root->isLeaf = 1;
        int yes = 0,no = 0;
        for(auto i : database) i.back() == "yes" ? yes++ : no++;
        if(yes >= no) root->attrb = "yes";
        else root->attrb = "no";
        return root;
    }

    string splittingAttrb = bestSlittingMeasure(database,remAttrb);
    root->attrb = splittingAttrb;
    root->isLeaf = 0;

    vector<string> temp;
    for(auto i : remAttrb){
        if(i != splittingAttrb) temp.push_back(i);
    }
    remAttrb = temp;

    int ind = inverseMapper[splittingAttrb];

    for(auto i : unqAttrbClass[splittingAttrb]){
        vector<vector<string>> newDatabase;
        for(auto j : database){
            if(j[ind] == i) newDatabase.push_back(j);
        }
        if(newDatabase.empty()){
            Node *tempNode = new Node();
            tempNode->isLeaf = 1;
            int yes = 0,no = 0;
            for(auto i : database) i.back() == "yes" ? yes++ : no++;
            if(yes >= no) tempNode->attrb = "yes";
            else tempNode->attrb = "no";
            root->branch[i] = tempNode;
        } 
        else root->branch[i] = bulidTree(newDatabase,temp);    
    }
    return root;
}

void traverseTree(Node *root){
    if(!root) return;
    cout<<root->attrb<<' '<<(root->isLeaf ? "class" : "attribute")<<'\n';
    string attrb = root->attrb;
    for(auto i : unqAttrbClass[attrb]){
        traverseTree(root->branch[i]);
    }
}

int main(){
    database_reader("data.txt");
    Node *root = bulidTree(database,Attrb);
    traverseTree(root);
}   