#include<bits/stdc++.h>
using namespace std;

#define X first
#define Y second
#define K 3
#define MAX_ITER 10

int Xmin = INT_MAX,Ymin = INT_MAX,Xmax = INT_MIN,Ymax = INT_MIN;

fstream rd;


int random(int i,int j){
	return rand()%(j - i + 1) + i;
}

vector<pair<int,int>> data_reader(string filename){
	vector<pair<int,int>> data;
	rd.open(filename,ios::in);
	string s,a;
	while(getline(rd,s)){
		stringstream obj(s);
		int x = -1,y = -1;
		while(obj>>a){
			if(x == -1) x = stoi(a);
			else if(y == -1) y = stoi(a);
		}
        Xmin = min(Xmin,x);
        Ymin = min(Ymin,y);

        Xmax = max(Xmax,x);
        Ymax = max(Ymax,y);
		data.emplace_back(x,y);
	}
	return data;
}

int manhattan_dist(pair<int,int> &A,pair<int,int> &B){
    return abs(A.X - B.X) + abs(A.Y - B.Y);
}

int cost(vector<set<pair<int,int>>> &clusters,vector<pair<int,int>> &medoids){
    int total_cost = 0;

    for(int i = 0;i < K;i++){
        int cst = 0;
        for(auto j : clusters[i]){
            cst += manhattan_dist(j,medoids[i]);
        }
        total_cost += cst;
    }
    return total_cost;
}

int main(){
    vector<pair<int,int>> data = data_reader("data.txt");

	vector<set<pair<int,int>>> clusters(K),final;
	
	vector<pair<int,int>> medoids(K);
	
	int iter = 0,curr_cost = INT_MAX,prev_cost = INT_MAX;
	
	while(++iter < MAX_ITER){
        for(int i = 0;i < K;i++){
		    pair<int,int> temp = {random(Xmin,Xmax),random(Ymin,Ymax)};
		    medoids[i] = temp;
	    }
		for(auto i : data){
			int min_dist = 999999;
			int cent_ind = 0;
			for(int j = 0;j < K;j++){
				int dist = manhattan_dist(i,medoids[j]);
				if(dist < min_dist){
					min_dist = dist;
					cent_ind = j;
				}
			}
			clusters[cent_ind].insert(i);
		}
        prev_cost = curr_cost;
        curr_cost = cost(clusters,medoids);    
        if(prev_cost < curr_cost) break;

		cout<<"\nAfter Iteration #"<<iter<<" Cost : "<<curr_cost<<"\n\n"; 
		for(int j = 0;j < K;j++){
			cout<<"Cluster #"<<j+1<<" : \n";
			cout<<"Medoid = "<<medoids[j].X<<' '<<medoids[j].Y<<'\n';
			cout<<"Cluster points : \n";
			for(auto i : clusters[j]){
				cout<<i.X<<' '<<i.Y<<'\n';
			}
			cout<<"\n--------------------------------\n"; 
		}	
		final = clusters;
		for(int j = 0;j < K;j++) clusters[j].clear();
	}
}