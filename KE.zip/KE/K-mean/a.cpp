#include<bits/stdc++.h>
using namespace std;

#define SIZE 15
#define X first
#define Y second
#define K 2

fstream rd,wrt;

int random(int i,int j){
	return rand()%(j - i + 1) + i;
}

void random_database(){
	wrt.open("data.txt",ios::out);
	for(int i = 0;i < SIZE;i++){
		wrt<<random(1,1000)<<" "<<random(1,1000)<<'\n';		
	}	
	wrt.close();
	cout<<"Database created\n";
}


double euclidian_dist(pair<int,int> &A,pair<int,int> &B){
	return  0.0 + sqrt( (A.X - B.X)*(A.X - B.X) + (A.Y - B.Y)*(A.Y - B.Y) );
}

vector<pair<int,int>> data_reader(string filename){
	vector<pair<int,int>> data;
	rd.open(filename,ios::in);
	string s,a;
	while(getline(rd,s)){
		stringstream obj(s);
		int x = -1,y = -1;
		while(obj>>a){
			if(x == -1) x = stoi(a);
			else if(y == -1) y = stoi(a);
		}
		data.emplace_back(x,y);
	}
	return data;
}


pair<int,int> cluster_mean(set<pair<int,int>> &clust,pair<int,int> &cent){
	int x = 0,y = 0,N = clust.size();
	if(N == 0) return cent;
	for(auto i : clust){
		x += i.X;
		y += i.Y;
	}
	return {x/N,y/N};
}

 

int main(){
	//random_database();
	vector<pair<int,int>> data = data_reader("data.txt");
	
	vector<set<pair<int,int>>> clusters(K),final;
	
	vector<pair<int,int>> centroids(K);
	
	for(int i = 0;i < K;i++){
		pair<int,int> temp = {random(1,100),random(1,100)};
		centroids[i] = temp;
	}
	
	int iter = 10;
	
	while(iter--){
		for(auto i : data){
			double min_dist = 999999.00;
			int cent_ind = 0;
			for(int j = 0;j < K;j++){
				double dist = euclidian_dist(i,centroids[j]);
				
				if(dist < min_dist){
					min_dist = dist;
					cent_ind = j;
				}
			}
			clusters[cent_ind].insert(i);
		}
		for(int j = 0;j < K;j++){
			centroids[j] = cluster_mean(clusters[j],centroids[j]);
		}
		
		cout<<"\nAfter Iteration #"<<10 - iter<<"\n\n"; 
		for(int j = 0;j < K;j++){
			cout<<"Cluster #"<<j+1<<" : \n";
			cout<<"Centroid = "<<centroids[j].X<<' '<<centroids[j].Y<<'\n';
			cout<<"Cluster points : \n";
			for(auto i : clusters[j]){
				cout<<i.X<<' '<<i.Y<<'\n';
			}
			cout<<"\n--------------------------------\n"; 
		}	
		final = clusters;
		for(int j = 0;j < K;j++) clusters[j].clear();
	}
	/*
	cout<<"\nFinal \n : ";
	for(int j = 0;j < K;j++){
		cout<<"Cluster #"<<j+1<<" : \n";
		cout<<"Centroid = "<<centroids[j].X<<' '<<centroids[j].Y<<'\n';
		cout<<"Cluster points : \n";
		for(auto i : final[j]){
			cout<<i.X<<' '<<i.Y<<'\n';
		}
		cout<<"\n--------------------------------\n"; 
	}
	*/
}
