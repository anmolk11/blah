#include<bits/stdc++.h>
using namespace std;

// likelyhood tables
vector<unordered_map<string,unordered_map<string,double>>> likelyhood_tables(4);

double pyes,pno;
int yes,no;

struct Tuple{
    string age;
    string income;
    string student;
    string credit_rating;
    string class_buys_computer;

    Tuple(string a,string i,string s,string crd,string cls){
        age = a;
        income = i;
        student = s;
        credit_rating = crd;
        class_buys_computer = cls;
    }
    void static print_attrb(){
        cout<<"age"<<setw(14)<<"income"<<setw(13)<<"student"<<setw(20)<<"credit_rating"<<setw(25)<<"class:buys_computer\n";
    }
    
    void print(){
        cout<<age<<setw(10)<<income<<setw(12)<<student<<setw(20)<<credit_rating<<setw(20)<<class_buys_computer<<'\n';
    }
};

class Table{
    public:
    vector<Tuple> database;
    void insert(vector<string> &tuple){
        Tuple temp = Tuple(tuple[0],tuple[1],tuple[2],tuple[3],tuple[4]);
        database.push_back(temp);
    }
    void print(){
        cout<<"\n==============================================================================\n";
        Tuple::print_attrb();
        cout<<"==============================================================================\n";
        for(auto i : database){
            i.print();
        }
        cout<<"==============================================================================\n";
    }
};


void LikelyHoodTableGenrator(Table &Table){
    int ttl = 0;

    for(auto i : Table.database){
        ttl++;
        if(i.class_buys_computer == "yes") pyes++,yes++;
        else pno++,no++;
    }
    pyes /= ttl;
    pno /= ttl;

    unordered_map<string,pair<int,int>> freq_table;
    
    // Age
    for(auto i : Table.database){
        if(i.class_buys_computer == "yes") freq_table[i.age].first += 1;
        else freq_table[i.age].second += 1;
    }

    for(auto i : freq_table){
        likelyhood_tables[0][i.first]["yes"] = (i.second.first + 0.0) / yes;
        likelyhood_tables[0][i.first]["no"] = (i.second.second + 0.0) / no;
    }
    freq_table.clear();

    // Income
    for(auto i : Table.database){
        if(i.class_buys_computer == "yes") freq_table[i.income].first += 1;
        else freq_table[i.income].second += 1;
    }

    for(auto i : freq_table){
        likelyhood_tables[1][i.first]["yes"] = (i.second.first + 0.0) / yes;
        likelyhood_tables[1][i.first]["no"] = (i.second.second + 0.0) / no;
    }
    freq_table.clear();

    // student
    for(auto i : Table.database){
        if(i.class_buys_computer == "yes") freq_table[i.student].first += 1;
        else freq_table[i.student].second += 1;
    }

    for(auto i : freq_table){
        likelyhood_tables[2][i.first]["yes"] = (i.second.first + 0.0) / yes;
        likelyhood_tables[2][i.first]["no"] = (i.second.second + 0.0) / no;
    }

    freq_table.clear();

    // credit_rating
    for(auto i : Table.database){
        if(i.class_buys_computer == "yes") freq_table[i.credit_rating].first += 1;
        else freq_table[i.credit_rating].second += 1;
    }

    for(auto i : freq_table){
        likelyhood_tables[3][i.first]["yes"] = (i.second.first + 0.0) / yes;
        likelyhood_tables[3][i.first]["no"] = (i.second.second + 0.0) / no;
    }
    freq_table.clear();
}

vector<string> split(string &A){
    vector<string> res;
    stringstream obj(A);
    string x;
    while(obj>>x) res.push_back(x);
    return res;
}

void TableBuilder(string filename,Table &A){
    fstream rd(filename,ios::in);
    string x;
    while(getline(rd,x)){
        vector<string> T = split(x);
        A.insert(T);
    }
}

bool testData(Tuple &test){
    double Yes,No;
    
    Yes = pyes * likelyhood_tables[0][test.age]["yes"] * likelyhood_tables[1][test.income]["yes"] * likelyhood_tables[2][test.student]["yes"] * likelyhood_tables[3][test.credit_rating]["yes"];
    No = pno * likelyhood_tables[0][test.age]["no"] * likelyhood_tables[1][test.income]["no"] * likelyhood_tables[2][test.student]["no"] * likelyhood_tables[3][test.credit_rating]["no"];

    Yes = (Yes)/(Yes + No);
    No = (No)/(Yes + No);

    return Yes >= No;
}


int main(){
    Table database;
    TableBuilder("data.txt",database);
    LikelyHoodTableGenrator(database);

    int tc = 0;
    while(tc != 2){
        cout<<"\n\n1.Testing\n";
        cout<<"2.Exit\n";
        cout<<"Enter : "; cin>>tc;

        if(tc == 1){
            string age,income,credit_rating,student;
            cout<<"Enter age group : "; cin>>age;
            cout<<"Enter income group : "; cin>>income;
            cout<<"Enter student or not : "; cin>>student;
            cout<<"Enter credit_rating group : "; cin>>credit_rating;

            Tuple tpl(age,income,student,credit_rating,"");

            bool yes = testData(tpl);

            if(yes) cout<<"Class : Yes\n";
            else cout<<"Class : No\n";
        }
        else break;
    }
}