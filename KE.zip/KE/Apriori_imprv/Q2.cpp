/*
@author : Anmol Khandelwal
@roll number : 207908
*/

#include<bits/stdc++.h>
using namespace std;

fstream wrt,rd;




void subset(int i,vector<string> &A,vector<string> &S,vector<vector<string>> &Ans){
    if(i == A.size()){
        if(!S.empty()) Ans.push_back(S);
        return;
    }
    S.push_back(A[i]);
    subset(i+1,A,S,Ans);
    S.pop_back();
    subset(i+1,A,S,Ans);
}

map<vector<string>,int> subset_freq(vector<vector<string>> &data){
    map<vector<string>,int> ss_freq;
    
    vector<string> S;
    vector<vector<string>> ss;
    unordered_set<string> unq;
    
    for(auto i : data){
        S.clear();
        ss.clear();
        subset(0,i,S,ss);
        for(auto k : ss){
            vector<string> xx = k;
            sort(xx.begin(),xx.end());
            ss_freq[xx]++;
        }
    }
    return ss_freq;
}

vector<string> split(string &x){
    vector<string> res;
    string a;
    int k = 0;
    stringstream obj(x);
    while(obj>>a){
        if(k != 0) res.push_back(a);
        k++;
    }
    return res;
}

vector<vector<string>> transaction_reader(string file_name){
    rd.open(file_name,ios::in);
    vector<vector<string>> res;
    string s;
    int k = 0;
    while(getline(rd,s)){
        vector<string> A = split(s);
        res.push_back(A);
    }
    return res;
}

int main(){
    vector<vector<string>> data = transaction_reader("data.txt");

    map<vector<string>,int> ss_freq_global = subset_freq(data);
     
    int N = data.size();

    int part_size = 3;

    double min_sup = 0.35;

    int transaction_per_part = N / part_size;

    int min_sup_count_local = round(min_sup * transaction_per_part);

    vector<vector<vector<string>>> part(part_size);

    vector<map<vector<string>,int>> part_freq(part_size); 

    int k = 0;

    

    for(int i = 0;i < part_size;i++){
        int t = transaction_per_part;
        while(t--){
            vector<string> temp;
            vector<vector<string>> res;
            subset(0,data[k],temp,res);
            for(auto d : res){
                part[i].push_back(d);
                vector<string> xx = d; 
                sort(xx.begin(),xx.end());
                part_freq[i][xx]++;
            }
            k++;
        }
    }

    set<vector<string>> L2;

    for(int i = 0;i < part_size;i++){
        for(auto k : part_freq[i]){
            if(k.second >= min_sup_count_local) L2.insert(k.first);
        }
    }

    int min_sup_count_global = round(N * min_sup);
    
    cout<<"Global output is : \n";

    wrt.open("Q2_global_output.txt",ios::out);

    
    for(auto i : L2){
        vector<string> xx = i;
        sort(xx.begin(),xx.end());
        if(ss_freq_global[xx] >= min_sup_count_global){
            for(auto k : xx) cout<<k<<' ',wrt<<k<<' ';
            cout<<'\n',wrt<<'\n';
        }
    }
}