/*
@author : Anmol Khandelwal
@roll number : 207908
*/

#include<bits/stdc++.h>
using namespace std;

fstream rd,wrt;

int min_support_count = 3;



void subset(int i,vector<string> &A,vector<string> &S,vector<vector<string>> &Ans){
    if(i == A.size()){
        if(!S.empty()) Ans.push_back(S);
        return;
    }
    S.push_back(A[i]);
    subset(i+1,A,S,Ans);
    S.pop_back();
    subset(i+1,A,S,Ans);
}

map<vector<string>,int> subset_freq(map<string,vector<string>> &data){
    map<vector<string>,int> ss_freq;
    
    vector<string> S;
    vector<vector<string>> ss;
    unordered_set<string> unq;
    
    for(auto i : data){
        S.clear();
        ss.clear();
        subset(0,i.second,S,ss);
        for(auto k : ss){
            vector<string> tx = k; sort(tx.begin(),tx.end()); 
            ss_freq[tx]++;
        }
    }

    return ss_freq;
}

vector<string> split(string &x){
    vector<string> res;
    string a;
    stringstream obj(x);
    while(obj>>a){
        res.push_back(a);
    }
    return res;
}

map<string,vector<string>> transaction_reader(string file_name){
    rd.open(file_name,ios::in);
    map<string,vector<string>> res;
    string s;
    while(getline(rd,s)){
        vector<string> A = split(s);
        for(int i = 1;i < A.size();i++){
            res[A[0]].push_back(A[i]);
        }
    }
    return res;
}

int order_of(string &item){
    return stoi(item.substr(1));
}

int hash_value(vector<string> &item_set){
    int k = item_set.size();
    if(k == 2){
        return (10 * order_of(item_set[0]) + order_of(item_set[1])) % 7; 
    }
    if(k == 3){
        (10 * order_of(item_set[0]) + 5 * order_of(item_set[1]) + order_of(item_set[2])) % 7; 
    }
}

int custom_hash_value(vector<string> &item_set){
    int k = item_set.size();
    if(k == 2){
        return (order_of(item_set[0]) + order_of(item_set[1])) % 7; 
    }
    if(k == 3){
        (order_of(item_set[0]) + order_of(item_set[1]) + order_of(item_set[2])) % 7; 
    }
}

int main(){
    map<string,vector<string>> data = transaction_reader("data.txt");

    map<vector<string>,int> ss_freq = subset_freq(data);


    wrt.open("hash_based_output.txt",ios::out);

    

    set<string> unq;

    for(auto i : data){
        for(auto k : i.second) unq.insert(k);
    }

    vector<string> C1(unq.begin(),unq.end());

    //for(auto i : C1) cout<<i<<'\n';

    vector<vector<string>> L2;

    for(int i = 0;i < C1.size();i++){
        for(int j = i+1;j < C1.size();j++){
            L2.push_back({C1[i],C1[j]});
        }
    }

    vector<vector<vector<string>>> H2(7);

    vector<int> bucket_count(7,0);

    
    //with hash function as given in problem
    for(auto i : L2){
        int h_value = hash_value(i);
        if(ss_freq.find(i) != ss_freq.end()) H2[h_value].push_back(i);
    }
    


    /*
    // with custom hash function (x + y) % 7;
    for(auto i : L2){
        int h_value = custom_hash_value(i);
        if(ss_freq.find(i) != ss_freq.end()) H2[h_value].push_back(i);
    }
    */
    
    for(int i = 0;i < 7;i++){
        for(auto j : H2[i]){
            bucket_count[i] += ss_freq[j];
        }
    }
    
    vector<int> next_step;

    for(int i = 0;i < 7;i++){
        cout<<"Bucket #"<<i<<'\n';
        cout<<"Bucket count : "<<bucket_count[i]<<"\n\n";
        wrt<<"Bucket #"<<i<<'\n';
        wrt<<"Bucket count : "<<bucket_count[i]<<"\n\n";
        if(bucket_count[i] >= min_support_count) next_step.push_back(i); 
        for(auto j : H2[i]){
            for(auto k : j) cout<<k<<' ',wrt<<k<<' ';
            cout<<'\n',wrt<<'\n';
        }
        cout<<"\n-----------------\n";
        wrt<<"\n-----------------\n";
    }

    unq.clear();

    cout<<"\nC2 have items from buckets : ";
    wrt<<"\nC2 have items from buckets : ";

    for(auto i : next_step){
        cout<<i<<' ';
        wrt<<i<<' '; 
        for(auto k : H2[i]){
            for(auto s : k) unq.insert(s);
        }
    }

    cout<<"\n\nC2 : ";
    wrt<<"\n\nC2 : ";

    for(auto i : unq) cout<<i<<' ',wrt<<i<<' ';
}